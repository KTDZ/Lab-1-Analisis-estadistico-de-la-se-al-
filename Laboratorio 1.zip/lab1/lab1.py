# -*- coding: utf-8 -*-
"""
Editor de Spyder

Este es un archivo temporal.
"""

# Importación de librerías necesarias
import wfdb  # Librería para cargar y manipular registros de señales fisiológicas
import numpy as np  # Librería para operaciones matemáticas y manejo de matrices
import matplotlib.pyplot as plt  # Librería para graficar datos
from scipy.stats import norm  # Librería para ajustar distribuciones normales y funciones de probabilidad

# Cargar la señal desde archivos locales (.dat y .hea)
senal = wfdb.rdrecord('a01')  # Se carga la señal fisiológica

# Verificación del número de señales en el archivo
print("Número de señales:", senal.n_sig)  # Imprime cuántas señales hay en el archivo

# Visualizar los valores de la señal
print("Valores de la señal:\n", senal.p_signal)  # Muestra los valores de la señal cargada

# Visualizar la longitud de la señal (número de muestras)
print("Longitud de la señal:", senal.sig_len)  # Imprime la cantidad de muestras de la señal

# Almacenar los valores de la señal en una variable para su manipulación posterior
valores = senal.p_signal  # Se almacena la señal en la variable 'valores'

# Graficar la señal para visualización
plt.figure(figsize=(12, 4))  # Define el tamaño de la figura
plt.plot(valores)  # Grafica los valores de la señal
plt.title('Señal ECG')  # Título del gráfico
plt.xlabel('Muestras')  # Etiqueta para el eje X
plt.ylabel('Amplitud')  # Etiqueta para el eje Y
plt.grid(True)  # Añadir una cuadrícula para facilitar la interpretación
plt.show()  # Muestra el gráfico

# Calcular la media, desviación estándar y coeficiente de variación para cada canal de la señal
mean_values = np.mean(valores, axis=0)  # Calcula la media de la señal
std_devs = np.std(valores, axis=0)  # Calcula la desviación estándar de la señal
coef_vars = std_devs / mean_values  # Calcula el coeficiente de variación

# Imprimir los resultados calculados para cada canal de la señal
for i in range(senal.n_sig):
    print(f"Señal {i+1}:")
    print(f"  Media: {mean_values[i]}")  # Muestra la media
    print(f"  Desviación estándar: {std_devs[i]}")  # Muestra la desviación estándar
    print(f"  Coeficiente de variación: {coef_vars[i]}")  # Muestra el coeficiente de variación

# Graficar un histograma de la señal y ajustar una función de probabilidad normal
plt.figure(figsize=(12, 4))  # Define el tamaño de la figura
plt.hist(valores[:, 0], bins=50, density=True, alpha=0.6, color='g')  # Grafica un histograma de la señal

# Ajustar una distribución normal a los datos del primer canal de la señal
mu, std = norm.fit(valores[:, 0])  # Ajusta la distribución normal y obtiene la media (mu) y desviación estándar (std)
xmin, xmax = plt.xlim()  # Obtiene los límites del eje X del gráfico
x = np.linspace(xmin, xmax, 100)  # Genera un conjunto de puntos para la distribución normal
p = norm.pdf(x, mu, std)  # Calcula la función de densidad de probabilidad para la distribución ajustada
plt.plot(x, p, 'k', linewidth=2)  # Grafica la función de densidad de probabilidad
plt.title('Histograma y función de probabilidad')  # Título del gráfico
plt.xlabel('Amplitud')  # Etiqueta para el eje X
plt.ylabel('Densidad de probabilidad')  # Etiqueta para el eje Y
plt.grid(True)  # Añadir una cuadrícula para facilitar la interpretación
plt.show()  # Muestra el gráfico

# Calcular estadísticos descriptivos usando funciones predefinidas de Python
mean_signal_builtin = np.mean(valores)  # Calcula la media usando una función predefinida
std_signal_builtin = np.std(valores)  # Calcula la desviación estándar usando una función predefinida
cv_signal_builtin = std_signal_builtin / mean_signal_builtin  # Calcula el coeficiente de variación

# Imprimir los resultados usando las funciones predefinidas
print(f'Media de la señal (predefinido): {mean_signal_builtin}')
print(f'Desviación estándar (predefinido): {std_signal_builtin}')
print(f'Coeficiente de variación (predefinido): {cv_signal_builtin}')

# Función para añadir ruido gaussiano a la señal
def add_gaussian_noise(signal, snr):
    if snr == 0:
        raise ValueError("El SNR no puede ser cero.")
    
    std_dev = np.std(signal)
    noise_scale = std_dev / abs(snr)
    
    noise = np.random.normal(0, noise_scale, signal.shape)  # Genera ruido gaussiano
    
    if snr > 0:
        noise_adjusted = noise  # Para SNR positivo, se usa el ruido calculado directamente
    else:
        noise_adjusted = noise * (10 ** (snr / 10))  # Para SNR negativo, amplifica el ruido
    
    return signal + noise_adjusted  # Retorna la señal con el ruido añadido

# Función para añadir ruido de impulsos a la señal
def add_impulse_noise(signal, snr):
    if snr == 0:
        raise ValueError("El SNR no puede ser cero.")
    
    noise = np.zeros(signal.shape)  # Inicializa un array de ceros del mismo tamaño que la señal
    num_impulses = max(1, int(len(signal) / abs(snr)))  # Calcula el número de impulsos
    
    impulse_positions = np.random.choice(len(signal), num_impulses, replace=False)  # Selecciona posiciones aleatorias
    
    if snr > 0:
        noise[impulse_positions] = np.max(signal)  # Añade impulsos de ruido
    else:
        noise[impulse_positions] = 6 * np.max(signal)  # Para SNR negativo, se amplifican los impulsos
    
    return signal + noise  # Retorna la señal con el ruido de impulsos añadido

# Función para añadir ruido de artefactos a la señal
def add_artifact_noise(signal, snr):
    if snr == 0:
        raise ValueError("El SNR no puede ser cero.")
    
    std_dev = np.std(signal)
    noise = np.sin(np.linspace(0, 2 * np.pi * 10, len(signal))) * (std_dev / abs(snr))  # Genera ruido
    
    if snr > 0:
        noise_adjusted = noise  # Para SNR positivo, se usa el ruido calculado directamente
    else:
        noise_adjusted = noise * (10 ** (snr / 10))  # Para SNR negativo, amplifica el ruido
    
    return signal + noise_adjusted  # Retorna la señal con el ruido de artefactos añadido

# Función para calcular la relación señal-ruido (SNR)
def calculate_snr(signal, noise_signal):
    signal_power = np.mean(signal ** 2)  # Calcula la potencia de la señal original
    noise_power = np.mean((signal - noise_signal) ** 2)  # Calcula la potencia del ruido
    snr = 10 * np.log10(signal_power / noise_power)  # Calcula el SNR en decibelios
    return snr  # Retorna el SNR, puede ser positivo o negativo

# Añadir ruido a la señal y calcular el SNR para cada tipo de ruido

# Ruido Gaussiano con SNR positivo
gaussian_noise_signal = add_gaussian_noise(valores[:, 0], 10)
snr_gaussian = calculate_snr(valores[:, 0], gaussian_noise_signal)
print(f'SNR con ruido gaussiano: {snr_gaussian} dB')

# Graficar la señal con ruido gaussiano y su histograma
plt.figure(figsize=(12, 4))
plt.plot(gaussian_noise_signal)
plt.title('Señal ECG con Ruido Gaussiano (SNR Positivo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(gaussian_noise_signal, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(gaussian_noise_signal)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido Gaussiano (SNR Positivo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()

# Ruido Gaussiano con SNR negativo
gaussian_noise_signal_negative = add_gaussian_noise(valores[:, 0], -10)
snr_gaussian_negative = calculate_snr(valores[:, 0], gaussian_noise_signal_negative)
print(f'SNR con ruido gaussiano negativo: {snr_gaussian_negative} dB')

# Graficar la señal con ruido gaussiano negativo y su histograma
plt.figure(figsize=(12, 4))
plt.plot(gaussian_noise_signal_negative)
plt.title('Señal ECG con Ruido Gaussiano (SNR Negativo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(gaussian_noise_signal_negative, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(gaussian_noise_signal_negative)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido Gaussiano (SNR Negativo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()

# Ruido de Impulsos con SNR positivo
impulse_noise_signal = add_impulse_noise(valores[:, 0], 10)
snr_impulse = calculate_snr(valores[:, 0], impulse_noise_signal)
print(f'SNR con ruido de impulsos: {snr_impulse} dB')

# Graficar la señal con ruido de impulsos y su histograma
plt.figure(figsize=(12, 4))
plt.plot(impulse_noise_signal)
plt.title('Señal ECG con Ruido de Impulsos (SNR Positivo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(impulse_noise_signal, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(impulse_noise_signal)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido de Impulsos (SNR Positivo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()

# Ruido de Impulsos con SNR negativo
impulse_noise_signal_negative = add_impulse_noise(valores[:, 0], -10)
snr_impulse_negative = calculate_snr(valores[:, 0], impulse_noise_signal_negative)
print(f'SNR con ruido de impulsos negativo: {snr_impulse_negative} dB')

# Graficar la señal con ruido de impulsos negativo y su histograma
plt.figure(figsize=(12, 4))
plt.plot(impulse_noise_signal_negative)
plt.title('Señal ECG con Ruido de Impulsos (SNR Negativo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(impulse_noise_signal_negative, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(impulse_noise_signal_negative)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido de Impulsos (SNR Negativo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()

# Ruido de Artefactos con SNR positivo
artifact_noise_signal = add_artifact_noise(valores[:, 0], 10)
snr_artifact = calculate_snr(valores[:, 0], artifact_noise_signal)
print(f'SNR con ruido de artefactos: {snr_artifact} dB')

# Graficar la señal con ruido de artefactos y su histograma
plt.figure(figsize=(12, 4))
plt.plot(artifact_noise_signal)
plt.title('Señal ECG con Ruido de Artefactos (SNR Positivo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(artifact_noise_signal, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(artifact_noise_signal)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido de Artefactos (SNR Positivo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()

# Ruido de Artefactos con SNR negativo
artifact_noise_signal_negative = add_artifact_noise(valores[:, 0], -10)
snr_artifact_negative = calculate_snr(valores[:, 0], artifact_noise_signal_negative)
print(f'SNR con ruido de artefactos negativo: {snr_artifact_negative} dB')

# Graficar la señal con ruido de artefactos negativo y su histograma
plt.figure(figsize=(12, 4))
plt.plot(artifact_noise_signal_negative)
plt.title('Señal ECG con Ruido de Artefactos (SNR Negativo)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 4))
plt.hist(artifact_noise_signal_negative, bins=50, density=True, alpha=0.6, color='g')
mu, std = norm.fit(artifact_noise_signal_negative)
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
plt.title('Histograma y función de probabilidad con Ruido de Artefactos (SNR Negativo)')
plt.xlabel('Amplitud')
plt.ylabel('Densidad de probabilidad')
plt.grid(True)
plt.show()
